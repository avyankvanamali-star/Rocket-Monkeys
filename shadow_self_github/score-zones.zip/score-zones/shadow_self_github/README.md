# Shadow Self — astronaut health engine (core, no UI)

## Dashboard app (easiest)
    python3 app.py                      # opens http://localhost:8000 in your browser (Ctrl + C to stop)
- Pick an astronaut and a day, see the 5 system scores, alerts, plan, trend, and every check.
- "Add a reading": type any measurement -> it's checked like a sensor reading, saved to
  data/manual.csv, and the engine re-runs. Use the next day number to add a new day.
- "Undo last entry" removes your last typed reading.
- "Data in" panel:
    - Upload CSV -> every row is checked; bad rows are skipped and counted.
        Add     = goes into data/uploaded.csv on top of everything else (new days / readings / astronauts)
        Replace = becomes data/mission.csv (and data/preflight.csv if the file has day 0 or earlier)
    - Generate sample data -> fresh preflight.csv + mission.csv, then the engine re-runs
    - Clear uploads + typed -> empties uploaded.csv and manual.csv
    - Download template -> example CSV with the exact columns
  Duplicate readings (same astronaut + time + metric) are skipped automatically; the newest one wins.

## Run it (VS Code terminal, inside this folder)
    python3 generate_sample_data.py     # makes data/preflight.csv + data/mission.csv (3 mission days)
    python3 main.py                     # runs the whole engine, prints a daily report

Only built-in Python is used (no pip installs).

## What you get
- Terminal: a daily report per astronaut (scores, alerts, rules fired, plan)
- `shadow_self.db`: open in a SQLite app (e.g. DB Browser for SQLite)
    - measurements: every reading (5-second streams + daily logs + tests)
    - baselines:    each astronaut's pre-mission normal
    - results:      every 7-step check (value, baseline, %, MDC, Shadow prediction, status, reason)
    - alerts:       every alert, with time and tier
    - plans:        countermeasures and the day they're scheduled
- `outputs/earth_summary_<astronaut>_day<N>.json`: the daily packet sent to Earth

## How the folders connect
    data/*.csv -> ingestion/ -> storage/ (shadow_self.db)
                     -> fast_checks/ (every 5 s: heartbeat, radiation)
                     -> modules/ (radiation, muscle, bone, sans, cardio) -- use pipeline/check.py + shadow_model/
                     -> fusion/ (cross-system rules + drift scores)
                     -> actions/ (alerts, plan, Earth summary, report)
All numbers/thresholds live in config/settings.py. Logic in plain English: PSEUDOCODE.md.

## Score zones (config/settings.py)
| Score | Level | What it means |
|---|---|---|
| 96-100 | Nominal | no extra observation |
| 95 and below | Watch | extra observations |
| below 90 | Act | basic medical care onboard |
| below 85 | Urgent | contact mission control |
Urgent is also raised by hard rules at any score (dangerous heart rhythm or rate, radiation event).
Each level adds its action to the daily plan. Demo thresholds, not medical standards.

## Radiation budget + space weather
Every day, each astronaut gets a radiation budget (terminal report, dashboard panel, Earth summary,
`radiation_budget` table, AI agent tool `get_radiation_budget`):
    career used (earlier flights + this mission) -> left before the 600 mSv career limit
    -> reserved for the rest of the mission (quiet daily rate + storm allowance) -> 10% safety margin
    -> SPARE = how much more radiation they can safely take, also shown as extra mission days.
Solar storm early warning from NOAA (`data/space_weather.csv`):
    python3 space_weather/feed.py --live     # adds the latest NOAA values (needs internet; run on a timer)
    python3 space_weather/feed.py            # shows what's in the file
Storm chance >= 50% or a storm seen near Earth -> ACT "prepare shelter, move spacewalks" BEFORE the
onboard dose rises. No feed or data older than 24 h -> onboard dosimeters only.
Earlier-flight doses and storm sizes in config/settings.py are DEMO values: replace them with real records.

## Feeding in your own data
Any CSV with columns: astronaut,time,metric,value,unit,source,quality,detail
(metric names must exist in config/settings.py METRICS). Save as data/mission.csv and run main.py.

## Fallbacks (it never crashes)
Every step is wrapped in `safe()` (pipeline/safe.py). If something breaks, the error goes to
`outputs/errors.log`, a fallback is used, and the run keeps going. A crashed system shows
"NO DATA" instead of a fake healthy score. Full list: PSEUDOCODE.md section 16.

## Planted test events in the sample data
Every test for all 5 systems runs every day in the demo so each system shows progress.
A1 = healthy control. A2 = drifting in every system (short workouts, high salt, low fluids, poor sleep, high CO2).
Change the story by editing the NORMAL / DAILY / TESTS / DRIFT tables at the top of generate_sample_data.py.
ECG strap slip (A2 day 1 06:00) · solar particle event (day 2 14:00) · stress episode (A2 day 2 20:00)
· irregular rhythm (A2 day 3 09:00) · dosimeter mismatch (A2 day 3) · 2 broken rows · 1 unit conversion.
Space weather (data/space_weather.csv, made up): storm chance 35% on day 1 evening, 60% on day 2 morning,
GOES sees the storm at 12:30 day 2 -> onboard spike at 14:00. 30-day data: warning before the day-20 storm,
and a feed outage on days 25-27 to show the onboard-only fallback.
All values are made up for testing; thresholds are demo values, not medical standards.
